# 🚦 SafeStreets AI

A Streamlit-powered app for real-time road hazard detection and scene summarization using YOLOv8 and BLIP.

## 💡 Features
- Detects objects (vehicles, pedestrians, hazards)
- Auto-generates scene captions using AI
- Web UI for uploading traffic videos and reviewing results

## 🛠️ How to Run

1. Clone the repo:
   ```bash
   git clone https://github.com/yourusername/SafeStreets-AI.git
   cd SafeStreets-AI
   ```

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Launch the app:
   ```bash
   streamlit run safestreets_ai.py
   ```

## 📈 Tech Stack
- YOLOv8 (Ultralytics)
- BLIP (Salesforce)
- Streamlit
- PyTorch

## 📜 License
MIT License
