# SafeStreets AI - Road Hazard Detection & Alert System (Streamlit Dashboard)

import cv2
import torch
import numpy as np
from torchvision import transforms
from PIL import Image
from ultralytics import YOLO
from transformers import BlipProcessor, BlipForConditionalGeneration
import streamlit as st
import tempfile
import os

# Load Models
detector = YOLO('yolov8n.pt')
processor = BlipProcessor.from_pretrained("Salesforce/blip-image-captioning-base")
caption_model = BlipForConditionalGeneration.from_pretrained("Salesforce/blip-image-captioning-base")

def detect_objects(image):
    results = detector(image)
    return results[0]

def generate_caption(image):
    inputs = processor(images=image, return_tensors="pt")
    out = caption_model.generate(**inputs)
    caption = processor.decode(out[0], skip_special_tokens=True)
    return caption

def draw_detections(image, results):
    for box in results.boxes:
        xyxy = box.xyxy[0].cpu().numpy().astype(int)
        label = box.cls[0].item()
        conf = box.conf[0].item()
        cv2.rectangle(image, (xyxy[0], xyxy[1]), (xyxy[2], xyxy[3]), (0, 255, 0), 2)
        cv2.putText(image, f"{detector.names[label]} {conf:.2f}", 
                    (xyxy[0], xyxy[1] - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 1)
    return image

def process_uploaded_video(video_file):
    tfile = tempfile.NamedTemporaryFile(delete=False)
    tfile.write(video_file.read())
    cap = cv2.VideoCapture(tfile.name)

    frame_count = 0
    captions = []

    output_path = os.path.join(tempfile.gettempdir(), "output.avi")
    fourcc = cv2.VideoWriter_fourcc(*'XVID')
    out = None

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        result = detect_objects(frame)
        frame = draw_detections(frame, result)

        if frame_count % 30 == 0:
            pil_image = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
            caption = generate_caption(pil_image)
            captions.append((frame_count, caption))

        if out is None:
            h, w, _ = frame.shape
            out = cv2.VideoWriter(output_path, fourcc, 20.0, (w, h))

        out.write(frame)
        frame_count += 1

    cap.release()
    out.release()
    os.unlink(tfile.name)

    return output_path, captions

def main():
    st.set_page_config(page_title="SafeStreets AI", layout="wide")
    st.title("🚦 SafeStreets AI - Road Hazard Detection & Scene Summarizer")
    st.write("Upload a traffic video to detect hazards and generate scene summaries.")

    video_file = st.file_uploader("Upload video", type=["mp4", "mov", "avi"])

    if video_file is not None:
        with st.spinner("Processing video..."):
            output_video_path, captions = process_uploaded_video(video_file)
        st.success("Processing complete!")

        st.video(output_video_path)
        st.subheader("Detected Scene Summaries")
        for frame_idx, cap in captions:
            st.write(f"Frame {frame_idx}: {cap}")

if __name__ == "__main__":
    main()
